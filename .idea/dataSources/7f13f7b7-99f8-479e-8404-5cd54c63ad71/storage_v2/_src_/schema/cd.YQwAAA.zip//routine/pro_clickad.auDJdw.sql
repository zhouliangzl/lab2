create procedure PRO_ClickAD(IN inaid int, IN inuid varchar(11), OUT massage varchar(2))
  label:BEGIN
    DECLARE deaduid varchar(11);
    DECLARE detype int;

    -- 访问量+1
    UPDATE ad SET click = click + 1 WHERE aid = inaid;
    SELECT deaduid = uid FROM ad WHERE aid = inaid;
    -- 管理员进入编辑页面
    SELECT detype = type FROM user WHERE uid = inuid;
    IF detype = 3 THEN
    SET massage =  '2';
    -- 非广告方本人进入详情页面
    END IF;
    IF inuid != deaduid THEN
      SET massage =  '1';
    -- 广告方本人进入编辑页面
    ELSE
      SET massage =  '2';
    END IF;
  END;

